import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// All the "generator" settings live in config.properties (next to this file),
// which you edit by hand (even from github.dev on a phone) — no code changes
// needed to make a new app. This completely replaces the old approach of
// binary-patching a compiled APK after the fact: real aapt2/Gradle now
// compiles these values in from the start, so there's no truncation limit,
// no hand-rolled ZIP/signature code, and no "package appears invalid" risk —
// the release build is signed for real by the Android Gradle Plugin.
val configProps = Properties().apply {
    val f = file("config.properties")
    // Explicit UTF-8 reader is required here: Properties.load(InputStream)
    // defaults to ISO-8859-1 and silently mangles non-ASCII text (e.g. a
    // Persian/Arabic app name), while Properties.load(Reader) respects
    // whatever charset the Reader was opened with.
    if (f.exists()) f.reader(Charsets.UTF_8).use { load(it) }
}
fun cfg(key: String, default: String): String = configProps.getProperty(key) ?: default

android {
    namespace = "com.template.webapp"
    compileSdk = 34

    defaultConfig {
        applicationId = cfg("packageName", "com.template.webapp")
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Compiled in for real by aapt2 — no length limit, no patching.
        resValue("string", "app_name", cfg("appName", "My Web App"))

        buildConfigField("String", "SITE_URL", "\"${cfg("siteUrl", "https://example.com")}\"")
        buildConfigField("boolean", "USE_LOCAL_SITE", cfg("useLocalSite", "false"))
        buildConfigField("String", "PRIMARY_COLOR", "\"${cfg("primaryColor", "#2962FF")}\"")
        buildConfigField("String", "PRIMARY_COLOR_DARK", "\"${cfg("primaryColorDark", "#0039CB")}\"")
        buildConfigField("boolean", "PULL_TO_REFRESH", cfg("pullToRefresh", "true"))
        buildConfigField("boolean", "ALLOW_EXTERNAL_LINKS", cfg("allowExternalLinks", "false"))
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        // Reuses the same debug keystore the Android Gradle Plugin
        // auto-generates on first use (~/.android/debug.keystore, created
        // fresh on every GitHub Actions run). Applying it to the RELEASE
        // build type too means the output is a real, properly
        // v1+v2(+v3)-signed, installable APK — signed by Google's own
        // tooling, not hand-rolled code. Good enough for sideloading/testing;
        // swap for your own upload key before publishing to Play Store.
        getByName("debug") {}
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
