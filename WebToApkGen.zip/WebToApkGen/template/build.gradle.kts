plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.template.webapp"
    compileSdk = 34

    defaultConfig {
        // Intentionally long/padded: ApkBuilder patches this string in-place
        // inside the compiled AndroidManifest.xml (see ArscStringPool) and can
        // only shrink it, never grow it. Keep target package names shorter
        // than this. See PackagePatcher.MAX_PACKAGE_NAME_LENGTH.
        applicationId = "com.template.webapp.reserved.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // IMPORTANT: leave this unsigned. The generator app (module :app)
            // strips/replaces signing itself, so we don't want Gradle's own
            // debug signature getting in the way of the ARSC patch step.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
