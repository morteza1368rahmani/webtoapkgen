package com.template.webapp

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import org.json.JSONObject

/**
 * The only screen of every generated app. All customization (URL, colors,
 * pull-to-refresh on/off, etc.) is data-driven: it comes from assets/config.json,
 * which ApkBuilder (in the :app module) rewrites for every project before
 * repackaging + signing. This class itself never changes between generated apps.
 */
class WebViewActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var config: AppConfig

    private data class AppConfig(
        val url: String,
        val localSite: Boolean,
        val pullToRefresh: Boolean,
        val allowExternalLinks: Boolean,
        val primaryColor: Int,
        val primaryColorDark: Int
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)

        config = loadConfig()
        window.statusBarColor = config.primaryColorDark
        findViewById<android.view.View>(R.id.swipeRefresh)?.setBackgroundColor(config.primaryColor)

        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)

        swipeRefresh.setOnRefreshListener { webView.reload() }
        swipeRefresh.isEnabled = config.pullToRefresh

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = config.localSite // only needed for bundled sites that call remote APIs
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 1..99) android.view.View.VISIBLE else android.view.View.GONE
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                swipeRefresh.isRefreshing = false
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val requestUrl = request.url
                val scheme = requestUrl.scheme ?: return false

                // Non-http(s) links (tel:, mailto:, whatsapp:, intent:, ...) get
                // handed off to whatever app on the device can open them.
                if (scheme != "http" && scheme != "https") {
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, requestUrl))
                        true
                    } catch (e: Exception) {
                        true // no app can handle it; swallow rather than crash
                    }
                }

                // Optionally keep the user inside the app even when a link points
                // to a different domain than the configured site. Bundled local
                // sites (file:///android_asset/...) are always considered "home".
                if (!config.allowExternalLinks && !config.localSite) {
                    val homeHost = Uri.parse(config.url).host
                    if (requestUrl.host != null && requestUrl.host != homeHost) {
                        startActivity(Intent(Intent.ACTION_VIEW, requestUrl))
                        return true
                    }
                }
                return false
            }
        }

        if (config.localSite) {
            webView.loadUrl("file:///android_asset/site/index.html")
        } else {
            webView.loadUrl(config.url)
        }
    }

    private fun loadConfig(): AppConfig {
        return try {
            val json = assets.open("config.json").bufferedReader().use { it.readText() }
            val obj = JSONObject(json)
            AppConfig(
                url = obj.optString("url", "https://example.com"),
                localSite = obj.optBoolean("localSite", false),
                pullToRefresh = obj.optBoolean("pullToRefresh", true),
                allowExternalLinks = obj.optBoolean("allowExternalLinks", false),
                primaryColor = safeParseColor(obj.optString("primaryColor", "#2962FF")),
                primaryColorDark = safeParseColor(obj.optString("primaryColorDark", "#0039CB"))
            )
        } catch (e: Exception) {
            AppConfig(
                url = "https://example.com", localSite = false, pullToRefresh = true, allowExternalLinks = false,
                primaryColor = android.graphics.Color.parseColor("#2962FF"),
                primaryColorDark = android.graphics.Color.parseColor("#0039CB")
            )
        }
    }

    private fun safeParseColor(hex: String): Int = try {
        android.graphics.Color.parseColor(hex)
    } catch (e: Exception) {
        android.graphics.Color.parseColor("#2962FF")
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
