plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.web2apk"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.web2apk"
        minSdk = 26          // needs java.nio.file + decent I/O APIs
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // apksig needs core library desugaring on minSdk < 26 features; not required at minSdk 26
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // The prebuilt template.apk lives under app/src/main/assets/template.apk
    // (see README "1. Build the template module" for how to produce it).
    androidResources {
        noCompress += "apk"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Official Android Gradle Plugin APK signer library — the SAME code
    // `apksigner` CLI uses. Handles v1 (JAR) + v2 + v3 signature schemes.
    implementation("com.android.tools.build:apksig:8.5.2")
}
