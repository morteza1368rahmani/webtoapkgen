package com.example.web2apk.core

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Calendar
import javax.security.auth.x500.X500Principal

/**
 * Every generated app needs to be signed. Real Play Store publishing
 * requires the developer's own upload key; this MVP auto-generates a
 * self-signed key **on first run**, using Android's built-in
 * `AndroidKeyStore` provider (hardware-backed where available) so we don't
 * need any third-party crypto library just to mint a certificate.
 *
 * The same key+cert is reused for every app generated afterwards, so
 * apps produced by a given install of this tool are all signed with the
 * same certificate (useful for update compatibility between them, but
 * NOT what you want for separate Play Store listings — see README).
 *
 * For real Play Store publishing, swap this for the developer's own
 * upload keystore — see the TODO in README.md.
 */
class KeystoreManager {

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "web2apk-signing-key"
    }

    private val keyStore: KeyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }

    /** Creates the signing key on first call; reuses it on every call after that. */
    fun getOrCreateSigningKey(): Pair<PrivateKey, X509Certificate> {
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            generateKey()
        }
        val privateKey = keyStore.getKey(KEY_ALIAS, null) as PrivateKey
        val cert = keyStore.getCertificate(KEY_ALIAS) as X509Certificate
        return privateKey to cert
    }

    private fun generateKey() {
        val start = Calendar.getInstance()
        val end = Calendar.getInstance().apply { add(Calendar.YEAR, 30) }

        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
            .setKeySize(2048)
            .setCertificateSubject(X500Principal("CN=Web2ApkGenerator, O=Generated, C=US"))
            .setCertificateSerialNumber(BigInteger.valueOf(System.currentTimeMillis()))
            .setCertificateNotBefore(start.time)
            .setCertificateNotAfter(end.time)
            .build()

        val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, ANDROID_KEYSTORE)
        kpg.initialize(spec)
        kpg.generateKeyPair() // AndroidKeyStore stores the key + self-signed cert as a side effect
    }
}
