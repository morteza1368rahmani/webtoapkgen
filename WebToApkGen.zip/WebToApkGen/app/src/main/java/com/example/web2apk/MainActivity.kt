package com.example.web2apk

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.example.web2apk.core.ApkBuilder
import com.example.web2apk.core.ApkConfig
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private var pickedIconPath: String? = null
    private var pickedHtmlPath: String? = null
    private var lastBuiltApk: File? = null

    private lateinit var iconPreview: ImageView
    private lateinit var appNameInput: EditText
    private lateinit var sourceModeUrl: RadioButton
    private lateinit var sourceModeFile: RadioButton
    private lateinit var urlInputLayout: TextInputLayout
    private lateinit var urlInput: EditText
    private lateinit var fileInputLayout: LinearLayout
    private lateinit var pickedHtmlLabel: TextView
    private lateinit var packageInput: EditText
    private lateinit var colorInput: EditText
    private lateinit var pullToRefreshCheck: CheckBox
    private lateinit var externalLinksCheck: CheckBox
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var installButton: Button

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { copyPickedIconToCache(it) }
    }

    private val pickHtml = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { copyPickedHtmlToCache(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        iconPreview = findViewById(R.id.iconPreview)
        appNameInput = findViewById(R.id.appNameInput)
        sourceModeUrl = findViewById(R.id.sourceModeUrl)
        sourceModeFile = findViewById(R.id.sourceModeFile)
        urlInputLayout = findViewById(R.id.urlInputLayout)
        urlInput = findViewById(R.id.urlInput)
        fileInputLayout = findViewById(R.id.fileInputLayout)
        pickedHtmlLabel = findViewById(R.id.pickedHtmlLabel)
        packageInput = findViewById(R.id.packageInput)
        colorInput = findViewById(R.id.colorInput)
        pullToRefreshCheck = findViewById(R.id.pullToRefreshCheck)
        externalLinksCheck = findViewById(R.id.externalLinksCheck)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)
        installButton = findViewById(R.id.installButton)

        findViewById<Button>(R.id.pickIconButton).setOnClickListener {
            pickImage.launch("image/*")
        }

        findViewById<RadioGroup>(R.id.sourceModeGroup).setOnCheckedChangeListener { _, checkedId ->
            val isFileMode = checkedId == R.id.sourceModeFile
            urlInputLayout.visibility = if (isFileMode) android.view.View.GONE else android.view.View.VISIBLE
            fileInputLayout.visibility = if (isFileMode) android.view.View.VISIBLE else android.view.View.GONE
        }

        findViewById<Button>(R.id.pickHtmlButton).setOnClickListener {
            // "*/*" so both text/html and application/zip show up reliably across devices
            pickHtml.launch("*/*")
        }

        findViewById<Button>(R.id.generateButton).setOnClickListener { onGenerateClicked() }

        installButton.setOnClickListener { lastBuiltApk?.let { installApk(it) } }
    }

    private fun copyPickedIconToCache(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: return
            val outFile = File(cacheDir, "picked_icon.png")
            input.use { ins -> FileOutputStream(outFile).use { ins.copyTo(it) } }
            pickedIconPath = outFile.absolutePath
            iconPreview.setImageBitmap(BitmapFactory.decodeFile(outFile.absolutePath))
        } catch (e: Exception) {
            toast("نتونستم آیکون رو بخونم: ${e.message}")
        }
    }

    private fun copyPickedHtmlToCache(uri: Uri) {
        try {
            val displayName = queryDisplayName(uri) ?: "site"
            val isZip = displayName.endsWith(".zip", ignoreCase = true)
            val outFile = File(cacheDir, if (isZip) "picked_site.zip" else "picked_site.html")
            val input = contentResolver.openInputStream(uri) ?: return
            input.use { ins -> FileOutputStream(outFile).use { ins.copyTo(it) } }
            pickedHtmlPath = outFile.absolutePath
            pickedHtmlLabel.text = "✓ انتخاب شد: $displayName"
        } catch (e: Exception) {
            toast("نتونستم فایل رو بخونم: ${e.message}")
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun onGenerateClicked() {
        val isFileMode = sourceModeFile.isChecked

        if (isFileMode && pickedHtmlPath == null) {
            toast("اول یه فایل .html یا .zip انتخاب کن")
            return
        }

        val config = try {
            ApkConfig(
                appName = appNameInput.text.toString().trim(),
                packageName = packageInput.text.toString().trim(),
                websiteUrl = if (isFileMode) null else urlInput.text.toString().trim(),
                localHtmlPath = if (isFileMode) pickedHtmlPath else null,
                primaryColorHex = colorInput.text.toString().trim().ifBlank { "#2962FF" },
                pullToRefresh = pullToRefreshCheck.isChecked,
                allowExternalLinks = externalLinksCheck.isChecked,
                customIconPath = pickedIconPath
            )
        } catch (e: IllegalArgumentException) {
            toast(e.message ?: "ورودی نامعتبر")
            return
        }

        if (config.appName.length > ApkBuilder.MAX_APP_NAME_LENGTH) {
            toast("اسم اپ باید حداکثر ${ApkBuilder.MAX_APP_NAME_LENGTH} کاراکتر باشه")
            return
        }

        setBusy(true)
        installButton.visibility = android.view.View.GONE

        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    ApkBuilder(applicationContext).build(config) { step ->
                        runOnUiThread { statusText.text = step }
                    }
                }
                lastBuiltApk = result.outputFile
                statusText.text = if (result.appNameTruncated) {
                    "✅ ساخته شد (توجه: اسم اپ کوتاه شد چون طولانی بود) — ${result.outputFile.name}"
                } else {
                    "✅ ساخته شد: ${result.outputFile.name}"
                }
                installButton.visibility = android.view.View.VISIBLE
            } catch (e: Exception) {
                statusText.text = "❌ خطا: ${e.message}"
            } finally {
                setBusy(false)
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        progressBar.visibility = if (busy) android.view.View.VISIBLE else android.view.View.GONE
        findViewById<Button>(R.id.generateButton).isEnabled = !busy
    }

    private fun installApk(apk: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
