package com.example.web2apk.core

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The package "name" field inside resources.arsc's ResTable_package chunk
 * is a *fixed* 128 x UTF-16 char (256 byte) buffer, always zero-padded by
 * aapt. That fixed size means — unlike everything in [ArscStringPool] —
 * we never have to worry about truncation here: any legal Java package
 * name comfortably fits in 127 characters.
 */
object ResTablePackagePatcher {

    private const val RES_TABLE_PACKAGE_TYPE = 0x0200
    private const val NAME_FIELD_OFFSET = 12 // ResChunk_header(8) + id(4)
    private const val NAME_FIELD_LENGTH_CHARS = 128

    fun patch(data: ByteArray, newPackageName: String): ByteArray {
        require(newPackageName.length < NAME_FIELD_LENGTH_CHARS) {
            "Package name too long (max ${NAME_FIELD_LENGTH_CHARS - 1} chars)"
        }
        val buf = data.copyOf()
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        var offset = 0

        while (offset + 8 <= buf.size) {
            val type = bb.getShort(offset).toInt() and 0xFFFF
            val chunkSize = bb.getInt(offset + 4)
            if (chunkSize <= 0 || offset + chunkSize > buf.size) break

            if (type == RES_TABLE_PACKAGE_TYPE) {
                val nameFieldStart = offset + NAME_FIELD_OFFSET
                // Zero the whole fixed slot, then write the new UTF-16LE name.
                for (i in 0 until NAME_FIELD_LENGTH_CHARS * 2) buf[nameFieldStart + i] = 0
                val newBytes = newPackageName.toByteArray(Charsets.UTF_16LE)
                System.arraycopy(newBytes, 0, buf, nameFieldStart, newBytes.size)
            }
            offset += chunkSize
        }
        return buf
    }
}
