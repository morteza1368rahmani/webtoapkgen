package com.example.web2apk.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Orchestrates turning one [ApkConfig] into a real, installable, signed
 * .apk file, entirely on-device:
 *
 *  1. Read every entry of the bundled template.apk into memory.
 *  2. Swap the entries that need to change:
 *       - assets/config.json      -> the user's URL/colors/options (plain text, trivial)
 *       - res/mipmap-*/ic_launcher*.png -> the user's icon, re-scaled per density
 *       - resources.arsc          -> app_name string patched in place (ArscStringPool)
 *       - AndroidManifest.xml     -> package name string patched in place (ArscStringPool)
 *                                    + the fixed-size package field in resources.arsc
 *                                    (ResTablePackagePatcher)
 *  3. Rebuild an unsigned zip from those (possibly modified) entries.
 *  4. Sign it with apksig (v1+v2+v3) using a locally generated key.
 *
 * Everything happens in the app's private cache dir; nothing touches the
 * original template.apk asset.
 */
class ApkBuilder(private val context: Context) {

    companion object {
        /** Must match the placeholder in template/src/main/res/values/strings.xml */
        private const val PLACEHOLDER_APP_NAME = "WebToApk Generated Application"

        /** Must match the padded applicationId in template/build.gradle.kts */
        private const val PLACEHOLDER_PACKAGE_PREFIX = "com.template.webapp.reserved."
        const val MAX_APP_NAME_LENGTH = PLACEHOLDER_APP_NAME.length

        private val ICON_DENSITIES = mapOf(
            "mipmap-mdpi" to 48,
            "mipmap-hdpi" to 72,
            "mipmap-xhdpi" to 96,
            "mipmap-xxhdpi" to 144,
            "mipmap-xxxhdpi" to 192
        )
    }

    data class BuildResult(val outputFile: File, val appNameTruncated: Boolean)

    fun build(config: ApkConfig, onProgress: (String) -> Unit = {}): BuildResult {
        onProgress("Reading template…")
        val entries = readTemplateEntries()

        onProgress("Writing config.json…")
        entries["assets/config.json"] = buildConfigJson(config).toByteArray(Charsets.UTF_8)

        if (config.isLocalSite) {
            onProgress("Bundling local site…")
            bundleLocalSite(entries, config.localHtmlPath!!)
        }

        if (config.customIconPath != null) {
            onProgress("Resizing icon…")
            applyCustomIcon(entries, config.customIconPath)
        }

        onProgress("Patching app name…")
        var truncated = false
        entries["resources.arsc"]?.let { arsc ->
            val result = ArscStringPool.replaceString(arsc, PLACEHOLDER_APP_NAME, config.appName)
            entries["resources.arsc"] = result.bytes
            truncated = result.truncated
        }

        onProgress("Patching package name…")
        val fullPlaceholderPackage = findPlaceholderPackageName(entries["AndroidManifest.xml"])
        if (fullPlaceholderPackage != null) {
            entries["AndroidManifest.xml"]?.let { manifest ->
                val result = ArscStringPool.replaceString(manifest, fullPlaceholderPackage, config.packageName)
                entries["AndroidManifest.xml"] = result.bytes
            }
            entries["resources.arsc"]?.let { arsc ->
                entries["resources.arsc"] = ResTablePackagePatcher.patch(arsc, config.packageName)
            }
        }

        onProgress("Rebuilding APK…")
        val unsignedApk = File(context.cacheDir, "unsigned_${System.currentTimeMillis()}.apk")
        writeZip(entries, unsignedApk)

        onProgress("Signing APK…")
        val outputDir = File(context.filesDir, "generated").apply { mkdirs() }
        val safeFileName = config.appName.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val signedApk = File(outputDir, "${safeFileName}_${System.currentTimeMillis()}.apk")

        val (privateKey, cert) = KeystoreManager().getOrCreateSigningKey()
        ApkSigner.sign(unsignedApk, signedApk, privateKey, cert)
        unsignedApk.delete()

        onProgress("Done.")
        return BuildResult(signedApk, truncated)
    }

    // --- template reading -------------------------------------------------

    private fun readTemplateEntries(): LinkedHashMap<String, ByteArray> {
        val result = LinkedHashMap<String, ByteArray>()
        context.assets.open("template.apk").use { input ->
            ZipInputStream(input).use { zin ->
                var entry: ZipEntry? = zin.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        result[entry.name] = zin.readBytes()
                    }
                    zin.closeEntry()
                    entry = zin.nextEntry
                }
            }
        }
        check(result.isNotEmpty()) { "template.apk missing or empty — see README step 1" }
        return result
    }

    private fun buildConfigJson(config: ApkConfig): String {
        return """
            {
              "url": "${config.websiteUrl ?: ""}",
              "localSite": ${config.isLocalSite},
              "pullToRefresh": ${config.pullToRefresh},
              "allowExternalLinks": ${config.allowExternalLinks},
              "primaryColor": "${config.primaryColorHex}",
              "primaryColorDark": "${config.primaryColorDarkHex}"
            }
        """.trimIndent()
    }

    /**
     * Bundles the user's local site under assets/site/ so the template's
     * WebViewActivity can load it with file:///android_asset/site/index.html
     * — no network needed at all (this is AppMint's "Single HTML / ZIP
     * Updater" feature).
     *
     *  - A single .html file is dropped in as assets/site/index.html.
     *  - A .zip (e.g. a small exported static site, with its own images/css/js)
     *    is fully extracted under assets/site/, preserving its internal paths.
     *    If it doesn't already contain an index.html at its root, the first
     *    .html file found becomes assets/site/index.html as well (copied,
     *    original path kept too) so the app always has an entry point.
     */
    private fun bundleLocalSite(entries: LinkedHashMap<String, ByteArray>, localPath: String) {
        val file = File(localPath)
        check(file.exists()) { "Selected file no longer exists: $localPath" }

        if (file.extension.equals("zip", ignoreCase = true)) {
            var foundRootIndex = false
            val allEntries = LinkedHashMap<String, ByteArray>()
            file.inputStream().use { input ->
                ZipInputStream(input).use { zin ->
                    var entry: ZipEntry? = zin.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val cleanName = entry.name.removePrefix("/")
                            allEntries["assets/site/$cleanName"] = zin.readBytes()
                            if (cleanName.equals("index.html", ignoreCase = true)) foundRootIndex = true
                        }
                        zin.closeEntry()
                        entry = zin.nextEntry
                    }
                }
            }
            check(allEntries.isNotEmpty()) { "The ZIP file is empty" }
            entries.putAll(allEntries)

            if (!foundRootIndex) {
                val firstHtml = allEntries.entries.firstOrNull { it.key.endsWith(".html", ignoreCase = true) }
                checkNotNull(firstHtml) { "No .html file found inside the ZIP" }
                entries["assets/site/index.html"] = firstHtml.value
            }
        } else {
            // Single HTML file mode
            entries["assets/site/index.html"] = file.readBytes()
        }
    }

    private fun applyCustomIcon(entries: LinkedHashMap<String, ByteArray>, iconPath: String) {
        val source = BitmapFactory.decodeFile(iconPath) ?: return
        for ((folder, size) in ICON_DENSITIES) {
            val scaled = Bitmap.createScaledBitmap(source, size, size, true)
            val png = ByteArrayOutputStream().apply { scaled.compress(Bitmap.CompressFormat.PNG, 100, this) }.toByteArray()
            entries["res/$folder/ic_launcher.png"] = png
            entries["res/$folder/ic_launcher_round.png"] = png
            if (scaled != source) scaled.recycle()
        }
        source.recycle()
    }

    /**
     * The manifest's binary string pool contains the padded placeholder
     * package name verbatim (AGP writes applicationId straight into the
     * `package` attribute). We don't know the exact padding length here,
     * so we scan the pool for any string starting with the known prefix.
     */
    private fun findPlaceholderPackageName(manifestBytes: ByteArray?): String? {
        if (manifestBytes == null) return null
        val text = String(manifestBytes, Charsets.UTF_16LE)
        val idx = text.indexOf(PLACEHOLDER_PACKAGE_PREFIX)
        if (idx < 0) return null
        var end = idx
        while (end < text.length && (text[end].isLetterOrDigit() || text[end] == '.' || text[end] == '_')) end++
        return text.substring(idx, end)
    }

    // --- zip writing --------------------------------------------------------

    private val storedEntries = setOf("resources.arsc", "AndroidManifest.xml")

    private fun writeZip(entries: Map<String, ByteArray>, output: File) {
        ZipOutputStream(output.outputStream().buffered()).use { zos ->
            for ((name, bytes) in entries) {
                val entry = ZipEntry(name)
                if (name in storedEntries) {
                    entry.method = ZipEntry.STORED
                    entry.size = bytes.size.toLong()
                    entry.compressedSize = bytes.size.toLong()
                    val crc = CRC32().apply { update(bytes) }
                    entry.crc = crc.value
                } else {
                    entry.method = ZipEntry.DEFLATED
                }
                zos.putNextEntry(entry)
                zos.write(bytes)
                zos.closeEntry()
            }
        }
    }
}
