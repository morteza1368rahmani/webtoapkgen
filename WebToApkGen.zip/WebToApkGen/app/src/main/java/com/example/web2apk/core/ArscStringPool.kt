package com.example.web2apk.core

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Patches strings *in place* inside a compiled Android binary resource
 * container (resources.arsc or the binary AndroidManifest.xml), both of
 * which embed one or more "ResStringPool" chunks using the same format.
 *
 * Why in-place: adding/removing bytes would shift every offset that comes
 * after it (chunk sizes, string offsets, XML attribute references, ...).
 * Re-computing all of those correctly is exactly what aapt2 does — and
 * exactly what we're avoiding here. In-place replacement sidesteps all of
 * it, at the cost of one rule: **the new string's encoded byte length must
 * be <= the original's**. Longer names get truncated (with a warning).
 *
 * This is the same "safe resource hacking" trick long used by APK
 * renaming tools; it only ever *shortens or equals*, never grows, so every
 * other offset in the file stays valid.
 *
 * Reference: android/frameworks/base .../ResourceTypes.h (struct
 * ResChunk_header, ResStringPool_header).
 */
object ArscStringPool {

    private const val RES_STRING_POOL_TYPE = 0x0001
    private const val UTF8_FLAG = 0x00000100

    data class PatchResult(val bytes: ByteArray, val truncated: Boolean)

    /**
     * Replaces every exact occurrence of [oldValue] found in any string pool
     * inside [data] with [newValue] (or a truncated prefix of it if it
     * doesn't fit). Returns the patched buffer plus whether truncation
     * happened anywhere.
     */
    fun replaceString(data: ByteArray, oldValue: String, newValue: String): PatchResult {
        val buf = data.copyOf()
        var truncatedAny = false
        var offset = 0

        while (offset + 8 <= buf.size) {
            val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
            val type = bb.getShort(offset).toInt() and 0xFFFF
            val headerSize = bb.getShort(offset + 2).toInt() and 0xFFFF
            val chunkSize = bb.getInt(offset + 4)

            if (chunkSize <= 0 || offset + chunkSize > buf.size) break // corrupt/end

            if (type == RES_STRING_POOL_TYPE) {
                val truncated = patchStringPoolChunk(buf, offset, oldValue, newValue)
                if (truncated) truncatedAny = true
            }

            offset += chunkSize
        }

        return PatchResult(buf, truncatedAny)
    }

    /** Returns true if the replacement had to be truncated to fit. */
    private fun patchStringPoolChunk(buf: ByteArray, chunkStart: Int, oldValue: String, newValue: String): Boolean {
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        val stringCount = bb.getInt(chunkStart + 8)
        val flags = bb.getInt(chunkStart + 16)
        val stringsStart = bb.getInt(chunkStart + 20)
        val isUtf8 = (flags and UTF8_FLAG) != 0

        var truncatedAny = false
        val offsetsBase = chunkStart + 28 // end of ResStringPool_header

        for (i in 0 until stringCount) {
            val relOffset = bb.getInt(offsetsBase + i * 4)
            val strStart = chunkStart + stringsStart + relOffset
            if (strStart < 0 || strStart >= buf.size) continue

            if (isUtf8) {
                if (tryPatchUtf8Entry(buf, strStart, oldValue, newValue)) truncatedAny = true
            } else {
                if (tryPatchUtf16Entry(buf, strStart, oldValue, newValue)) truncatedAny = true
            }
        }
        return truncatedAny
    }

    // --- UTF-16LE entries: [len:1or2 u16][chars...][0x0000] -------------------

    private fun tryPatchUtf16Entry(buf: ByteArray, start: Int, oldValue: String, newValue: String): Boolean {
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        var pos = start
        val firstWord = bb.getShort(pos).toInt() and 0xFFFF
        val extended = (firstWord and 0x8000) != 0
        val charLen: Int
        if (extended) {
            val secondWord = bb.getShort(pos + 2).toInt() and 0xFFFF
            charLen = ((firstWord and 0x7FFF) shl 16) or secondWord
            pos += 4
        } else {
            charLen = firstWord
            pos += 2
        }
        if (charLen <= 0 || charLen > 4000) return false // sanity guard

        val dataStart = pos
        val current = String(buf, dataStart, charLen * 2, Charsets.UTF_16LE)
        if (current != oldValue) return false

        var replacement = newValue
        var truncated = false
        if (replacement.length > charLen) {
            replacement = replacement.substring(0, charLen)
            truncated = true
        }

        val newBytes = replacement.toByteArray(Charsets.UTF_16LE)
        System.arraycopy(newBytes, 0, buf, dataStart, newBytes.size)
        // Zero-pad the rest of the original slot (harmless: length prefix below is updated).
        for (i in newBytes.size until charLen * 2) buf[dataStart + i] = 0

        // Update the length prefix to the new (possibly shorter) char count.
        val newBb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        if (extended) {
            newBb.putShort(start, (0x8000 or ((replacement.length shr 16) and 0x7FFF)).toShort())
            newBb.putShort(start + 2, (replacement.length and 0xFFFF).toShort())
        } else {
            newBb.putShort(start, replacement.length.toShort())
        }
        return truncated
    }

    // --- UTF-8 entries: [utf16len:1or2][utf8len:1or2][utf8 bytes][0x00] --------

    private fun tryPatchUtf8Entry(buf: ByteArray, start: Int, oldValue: String, newValue: String): Boolean {
        var pos = start

        // utf16 length (we don't need the value, just need to skip past it)
        val u16First = buf[pos].toInt() and 0xFF
        pos += if (u16First and 0x80 != 0) 2 else 1

        val u8First = buf[pos].toInt() and 0xFF
        val extended = (u8First and 0x80) != 0
        val byteLen: Int
        if (extended) {
            val u8Second = buf[pos + 1].toInt() and 0xFF
            byteLen = ((u8First and 0x7F) shl 8) or u8Second
            pos += 2
        } else {
            byteLen = u8First
            pos += 1
        }
        if (byteLen <= 0 || byteLen > 4000) return false

        val dataStart = pos
        val current = String(buf, dataStart, byteLen, Charsets.UTF_8)
        if (current != oldValue) return false

        var newBytes = newValue.toByteArray(Charsets.UTF_8)
        var truncated = false
        if (newBytes.size > byteLen) {
            // Trim on a char boundary so we don't cut a multi-byte UTF-8 sequence in half.
            var cut = byteLen
            while (cut > 0 && (newBytes[cut].toInt() and 0xC0) == 0x80) cut--
            newBytes = newBytes.copyOfRange(0, cut)
            truncated = true
        }

        System.arraycopy(newBytes, 0, buf, dataStart, newBytes.size)
        for (i in newBytes.size until byteLen) buf[dataStart + i] = 0

        // Update the byte-length prefix (utf16-length prefix is left as-is;
        // readers use the byte-length prefix to know how much to decode, and
        // a stale utf16 count only affects pre-sizing, not correctness).
        if (extended) {
            buf[pos - 2] = (0x80 or ((newBytes.size shr 8) and 0x7F)).toByte()
            buf[pos - 1] = (newBytes.size and 0xFF).toByte()
        } else {
            buf[pos - 1] = newBytes.size.toByte()
        }
        return truncated
    }
}
