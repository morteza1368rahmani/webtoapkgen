package com.example.web2apk.core

import com.android.apksig.ApkSigner
import java.io.File
import java.security.PrivateKey
import java.security.cert.X509Certificate

/**
 * Thin wrapper around `com.android.apksig.ApkSigner` — the exact library
 * the official `apksigner` command-line tool and Android Gradle Plugin use.
 * Handles zip alignment + v1 (JAR)/v2/v3 signature blocks for us, so we
 * don't have to hand-roll any of that.
 */
object ApkSigner {

    fun sign(
        unsignedApk: File,
        signedApkOutput: File,
        privateKey: PrivateKey,
        certificate: X509Certificate
    ) {
        val signerConfig = ApkSigner.SignerConfig.Builder(
            "web2apk",
            privateKey,
            listOf(certificate)
        ).build()

        val builder = ApkSigner.Builder(listOf(signerConfig))
            .setInputApk(unsignedApk)
            .setOutputApk(signedApkOutput)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .setMinSdkVersion(24)

        builder.build().sign()
    }
}
