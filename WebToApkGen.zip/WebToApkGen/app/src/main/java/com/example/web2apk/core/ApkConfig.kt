package com.example.web2apk.core

/**
 * Everything the user configures on the MainActivity screen for one
 * generated app. Mirrors (in spirit, not in scope) the ApkConfig object
 * we found in AppMint's decompiled source — just trimmed down to the
 * handful of fields this MVP actually implements.
 *
 * Source mode is one of the two, mutually exclusive:
 *  - websiteUrl set, localHtmlPath null  -> WebView loads a remote URL (original mode)
 *  - localHtmlPath set                   -> the chosen local HTML file (plus, if it's a
 *                                            zip, everything alongside it) is bundled
 *                                            straight into the APK's assets and loaded
 *                                            from disk — this is AppMint's "Single HTML /
 *                                            ZIP Updater" feature.
 */
data class ApkConfig(
    val appName: String,
    val packageName: String,
    val websiteUrl: String? = null,
    /** Absolute path to a user-picked .html or .zip (a whole site) to bundle offline. */
    val localHtmlPath: String? = null,
    val primaryColorHex: String = "#2962FF",
    val primaryColorDarkHex: String = "#0039CB",
    val pullToRefresh: Boolean = true,
    val allowExternalLinks: Boolean = false,
    /** Absolute path to a square PNG chosen by the user, or null to keep the default icon. */
    val customIconPath: String? = null
) {
    val isLocalSite: Boolean get() = localHtmlPath != null

    init {
        require(appName.isNotBlank()) { "App name can't be empty" }
        require(Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$").matches(packageName)) {
            "Package name must look like com.example.myapp"
        }
        require((websiteUrl != null) xor (localHtmlPath != null)) {
            "Provide exactly one source: either a website URL or a local HTML/ZIP file"
        }
        websiteUrl?.let {
            require(it.startsWith("http://") || it.startsWith("https://")) {
                "URL must start with http:// or https://"
            }
        }
    }
}
