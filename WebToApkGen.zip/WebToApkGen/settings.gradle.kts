pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "WebToApkGen"
// "app"      -> the generator app (the tool the end user runs)
// "template" -> the WebView shell that gets cloned/patched for every generated app
include(":app", ":template")
